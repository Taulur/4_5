import * as universal from "../../../../src/routes/zal2/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/zal2/+page.svelte";