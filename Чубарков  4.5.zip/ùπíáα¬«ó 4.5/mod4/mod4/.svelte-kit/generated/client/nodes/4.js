import * as universal from "../../../../src/routes/sinema/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/sinema/+page.svelte";