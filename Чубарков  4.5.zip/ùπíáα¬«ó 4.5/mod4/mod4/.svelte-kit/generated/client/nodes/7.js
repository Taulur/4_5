import * as universal from "../../../../src/routes/zal1/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/zal1/+page.svelte";